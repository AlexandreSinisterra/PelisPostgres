package org.example;

import org.example.model.Peliculas;
import org.example.service.ConexionService;
import org.example.service.PeliculasService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
// a
@Service
public class Secuencia {
    @Autowired
    private final ConexionService conexionService;
    @Autowired
    private final PeliculasService peliculasService;

    @Autowired
    public Secuencia(ConexionService conexionService, PeliculasService peliculasService) {
        this.conexionService = conexionService;
        this.peliculasService = peliculasService;
    }

    public void executar() {

        // Trae las películas de Postgres
       List<Peliculas> peliculas = conexionService.getAllPeliculas();

        // Implementa en MongoDB las peliculas que hemos traído de Postgres

        for(Peliculas peli : peliculas){
           peliculasService.crearPeliculas(peli);

       }

        //peliculasService.exportarJSON();
        peliculasService.importarDesdeJSON();

    }
}
