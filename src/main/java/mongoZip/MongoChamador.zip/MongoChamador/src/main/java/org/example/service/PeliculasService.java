package org.example.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import org.example.model.Actores;
import org.example.model.Peliculas;
import org.example.repository.ActoresRepository;
import org.example.repository.PeliculasRepository;
import org.springframework.stereotype.Service;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

@Service
public class PeliculasService {


    private final ActoresRepository actoresRepository;
    private final PeliculasRepository peliculasRepository;
    private final ObjectMapper objectMapper;


    public PeliculasService(ActoresRepository actoresRepository, PeliculasRepository peliculasRepository,ObjectMapper objectMapper) {
        this.actoresRepository = actoresRepository;
        this.peliculasRepository = peliculasRepository;
        this.objectMapper = objectMapper;

    }

    public void crearPeliculas(Peliculas peliculas){
        peliculasRepository.save(peliculas);
    }

    public List<Peliculas> findAllPeliculas(){
       return peliculasRepository.findAll();
    }

    public void exportarJSON(){
        List<Peliculas> peliculas = findAllPeliculas();
        Gson gson = new Gson();

        try(  FileWriter fileWriter = new FileWriter("/home/dam/Documentos/MongoDB_Postgres_Conexi-n-main/MongoChamador/src/main/java/org/example/JSON/prueba.json")) {

            String json = gson.toJson(peliculas);
            fileWriter.write(json);

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    public void importarDesdeJSON() {
        Gson gson = new Gson();
        // Ruta al archivo que creamos antes con los datos
        File archivo = new File("/home/dam/Documentos/MongoDB_Postgres_Conexi-n-main/MongoChamador/src/main/java/org/example/JSON/prueba.json");

        try (Reader reader = new FileReader(archivo)) {
            // Convertimos el contenido del JSON a una lista de objetos Peliculas
            Peliculas[] pelisArreglo = gson.fromJson(reader, Peliculas[].class);

            if (pelisArreglo != null) {
                for (Peliculas p : pelisArreglo) {
                    peliculasRepository.save(p);
                }
                System.out.println("Se han insertado " + pelisArreglo.length + " películas en MongoDB.");
            }
        } catch (IOException e) {
            System.err.println("Error al leer el archivo: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }

}
